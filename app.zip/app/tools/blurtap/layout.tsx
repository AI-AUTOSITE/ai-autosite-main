// app/tools/blurtap/layout.tsx

export default function BlurTapLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
